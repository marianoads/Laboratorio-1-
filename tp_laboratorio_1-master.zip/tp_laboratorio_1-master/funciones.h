#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED


float IngresarNumero(char);
void Sumar(float,float);
void Restar(float,float);
void Division(float,float);
void Multiplicacion(float,float);
void Factorial(float);
void MostrarTodoLosResultados(float,float);




#endif // FUNCIONES_H_INCLUDED
